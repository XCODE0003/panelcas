<?php

namespace App\Filament\Resources\SettingAdminResource\Pages;

use App\Filament\Resources\SettingAdminResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSettingAdmin extends CreateRecord
{
    protected static string $resource = SettingAdminResource::class;
}
